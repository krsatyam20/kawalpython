#Notepad Example
print("Hello Hi Kawal How are you ?")