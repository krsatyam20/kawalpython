#print("hello")

#add the value 
#print(10+20)

#print(2*3)
''' variable: Is A memory location where we can store our value 
 
'''
a=10 #Here a is an variable and 10 is value where a is hold the value 10

print(a)
a="Kawal"

print(a)

a=10 # store first integer value on variable a 
b=20 # store Second integer value on variable b

#Add value of a and b which is integer type and store on variable c 
c= a+b
print("add value of a and b =" ,c)


#integer

a=10

print(type(a))

a=10.1

print(type(a))



a=10.11

print(type(a))




a="10"

print(type(a))






