#Single comment 
#comment: Description of any object /Express our view on any object

'''   
Multiple Line comment 
Hi This is my First program 

'''

print("Hi Kawal hello") 