#addition
a=10
b=20
c= a+b
print("add value of a and b = ", c)


#Subtraction
a=40
b=20
c= a-b
print("sub value of a and b = ", c)


#Multiplicationf 
a=10
b=20
c= a*b
print("Mul value of a and b = ", c)


#Division 
a=60
b=20
c= a/b
print("Div value of a and b = ", c)

''' Variable define good way

always start with smallletters
    a9
    a@
    studentName
    student_name
    student-name

    
not use first letter as a number  3a/4 a
not use first letter as a any special char  @a !k

Name student (Wrong )
student Name(wrong)
'''



#Q Add 40 And 50

a=40
b=50

c=a+b 
print("Add value of a and b = ",C)


print(40+50)


